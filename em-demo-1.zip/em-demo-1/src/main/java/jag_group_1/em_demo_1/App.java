package jag_group_1.em_demo_1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Vehicle;
import model.VehicleService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
    	VehicleService vs=(VehicleService) ctx.getBean("vs");
    	vs.add(new Vehicle("Innova", "Cross over", "Toyota"));
        System.out.println( "Hello World!" );
    }
}
