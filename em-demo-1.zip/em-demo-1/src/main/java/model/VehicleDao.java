package model;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

@Component
public class VehicleDao {
	@PersistenceContext
	EntityManager em;
	
	public void create(Vehicle vehicle)
	{
		em.persist(vehicle);
	}
}
