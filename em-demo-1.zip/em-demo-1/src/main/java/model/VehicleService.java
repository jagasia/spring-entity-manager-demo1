package model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("vs")
public class VehicleService {
	@Autowired
	VehicleDao vdao;
	public void add(Vehicle vehicle)
	{
		vdao.create(vehicle);
	}
}
