package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Vehicle;
import model.VehicleService;

/**
 * Servlet implementation class VehicleServlet
 */
@WebServlet({ "/VehicleServlet", "/vehicle" })
public class VehicleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VehicleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		VehicleService vs = (VehicleService) ctx.getBean("vs");
		String btn=request.getParameter("btn");
		int id;
		String name, type, company;
		switch(btn)
		{
		case "Add":
		case "Modify":
			name=request.getParameter("name");
			type=request.getParameter("type");
			company=request.getParameter("company");
			Vehicle vehicle=new Vehicle(name, type, company);
			if(btn.equals("Modify"))
			{
				if(request.getParameter("id")==null)
					return;
				id=Integer.parseInt(request.getParameter("id"));
				vehicle.setId(id);
				vs.update(vehicle);
			}else
				vs.add(vehicle);
			break;
		case "Delete":
			if(request.getParameter("id")==null)
				return;
			id=Integer.parseInt(request.getParameter("id"));
			vs.delete(id);
			break;
		}
		response.sendRedirect("home");
	}

}
